def format_date(date_str, input_format='%Y-%m-%d', output_format='%B %d, %Y'):
    """将日期字符串从一种格式转换为另一种格式
    例如: format_date('2025-01-30') 返回 'January 30, 2025'
    """
    from datetime import datetime
    dt = datetime.strptime(date_str, input_format)
    return dt.strftime(output_format)

def word_count(text):
    """计算文本中的单词数量"""
    words = text.split()
    return len(words)

def to_markdown_table(data):
    """将字典列表转换为Markdown表格
    例如: to_markdown_table([{'name': 'Alan', 'age': 30}, {'name': 'Bob', 'age': 25}])
    """
    if not data or not isinstance(data, list) or not data[0]:
        return "Error: Invalid data format"
    
    # 获取表头
    headers = list(data[0].keys())
    
    # 创建表头行
    table = [f"| {' | '.join(headers)} |"]
    
    # 添加分隔行
    table.append(f"| {' | '.join(['---' for _ in headers])} |")
    
    # 添加数据行
    for row in data:
        table.append(f"| {' | '.join(str(row.get(h, '')) for h in headers)} |")
    
    return '\n'.join(table)
