def get_word_stats(doc):
    """获取当前文档的字数统计信息"""
    content = doc['content']
    words = content.split()
    chars = len(content)
    lines = content.count('\n') + 1
    
    return {
        'words': len(words),
        'characters': chars,
        'lines': lines,
        'title': doc['title']
    }

def get_metadata(doc):
    """获取当前文档的元数据"""
    from datetime import datetime
    
    created = datetime.fromtimestamp(doc['created']/1000)
    modified = datetime.fromtimestamp(doc['modified']/1000)
    
    return {
        'title': doc['title'],
        'path': doc['path'],
        'created': created.strftime('%Y-%m-%d %H:%M:%S'),
        'modified': modified.strftime('%Y-%m-%d %H:%M:%S'),
        'frontmatter': doc['frontmatter']
    }

def get_selection(doc):
    """获取当前选中的文本"""
    return doc['selection'] if doc['selection'] else "No text selected"

def insert_toc(doc):
    """生成文档的目录"""
    import re
    
    content = doc['content']
    lines = content.split('\n')
    toc = []
    
    for line in lines:
        if line.startswith('#'):
            level = len(re.match(r'^#+', line).group())
            title = line.lstrip('#').strip()
            indent = '  ' * (level - 1)
            toc.append(f"{indent}- {title}")
    
    return '\n'.join(toc) if toc else "No headers found"
